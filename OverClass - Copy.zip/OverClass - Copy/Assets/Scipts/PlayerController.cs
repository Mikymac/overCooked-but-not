﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public Items handItem = null;
    Rigidbody2D rb;
    public LayerMask layer;

    [Space]
    [Range(0.0f,5f)]
    public float distanceForRay = 0.4f;

    [Range(1, 100)]
    public float speed = 20;

    Vector2 direction = new Vector2(0, 0);

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        //Collects player movement
        Vector3 movement = new Vector3(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));

        //if the player isnt moving dont change its current directions
        if (movement != Vector3.zero)
        {
            direction = movement.normalized;
            //rotates the player to face the direction its moving in
            transform.eulerAngles = Vector3.forward * Mathf.Atan2(-direction.x, direction.y) * Mathf.Rad2Deg;
        }

        //moves the player
        rb.velocity = movement * Time.deltaTime * speed;

        //checks to see if a container is in front of them.
        RaycastHit2D hit = Physics2D.Raycast(transform.position, direction, distanceForRay, layer, Mathf.Infinity, Mathf.Infinity);
        //debugs the ray cast
        Debug.DrawRay(transform.position, direction, Color.yellow, distanceForRay);

        //if the ray hits something-
        if (hit.collider != null)
        {
            Debug.Log(hit.collider.name);
            //get the item inside its container
            Items containerItem = hit.transform.GetComponent<Inv>().item;
            if (Input.GetKeyDown(KeyCode.Q))
            {
                //if theres an item in the container but not the hand, switch the two
                if (handItem == null && containerItem != null)
                {
                    handItem = containerItem;
                    hit.transform.GetComponent<Inv>().item = null;
                }
                //if theres an item in the hand and not the container, switch the two
                else if (handItem != null && containerItem == null)
                {
                    hit.transform.GetComponent<Inv>().item = handItem;
                    handItem = null;
                }
                else
                    Debug.Log("Either you dont have an item or an item is currently stored in this container");
            }
        }
    }
}
