﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Inv : MonoBehaviour
{
    public Items item;

    public SpriteRenderer itemShower;

    Items CheckItem()
    {
        return item;
    }

    private void Update()
    {
        if (item != null)
        {
            itemShower.sprite = item.image;
        }
        else
            itemShower.sprite = null;
    }
}
