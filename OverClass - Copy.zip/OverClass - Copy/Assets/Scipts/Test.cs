﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Test Item", menuName = "Item/Test Item")]
public class Test : Items
{
    //extra shiz goes in here for individual objects
}
